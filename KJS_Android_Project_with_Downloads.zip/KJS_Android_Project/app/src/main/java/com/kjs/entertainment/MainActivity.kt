package com.kjs.entertainment

import android.app.Activity
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebSettings
import android.webkit.JavascriptInterface
import android.app.DownloadManager
import android.net.Uri
import android.os.Environment
import android.content.Context
import android.view.ViewGroup
import android.graphics.Color

class MainActivity : Activity() {
    private lateinit var webView: WebView

    @Suppress("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(17, 16, 24)
        window.navigationBarColor = Color.rgb(17, 16, 24)

        webView = WebView(this)
        webView.layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        webView.setBackgroundColor(Color.rgb(17, 16, 24))
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.mediaPlaybackRequiresUserGesture = true
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(KJSDownloadBridge(this), "KJSDownloads")
        webView.webViewClient = WebViewClient()
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}


class KJSDownloadBridge(private val activity: Activity) {
    @JavascriptInterface
    fun start(urlText: String, requestedName: String): String {
        return try {
            val uri = Uri.parse(urlText)
            val scheme = uri.scheme?.lowercase()
            if ((scheme != "https" && scheme != "http") || uri.host.isNullOrBlank()) {
                return "Please enter a valid direct HTTP(S) file URL."
            }
            val safeName = requestedName.substringAfterLast('/').substringAfterLast('\\\\')
                .replace(Regex("[^A-Za-z0-9._ -]"), "_")
                .take(100)
                .ifBlank { "kjs-video.mp4" }
            val request = DownloadManager.Request(uri)
                .setTitle(safeName)
                .setDescription("KJS authorised video download")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setAllowedOverMetered(true)
                .setAllowedOverRoaming(false)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, safeName)
            val manager = activity.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            manager.enqueue(request)
            "Download queued. Check the Android notification or Downloads folder."
        } catch (e: Exception) {
            "Could not start download. Check the URL and try again."
        }
    }
}
