KJS Android project (source, not a prebuilt APK)

Features:
- KJS HTML interface and authorised-source links.
- Direct HTTP(S) file download field using Android DownloadManager for sources that permit downloading.
- Android notification when a download completes.

Build an APK:
1. Install Android Studio on a computer.
2. Open this folder in Android Studio.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the generated APK path (usually app/build/outputs/apk/debug/app-debug.apk).

Important limitations:
- This ZIP is Android Studio source, not a prebuilt APK. It has not been compiled or tested here.
- The download field needs a direct video-file URL; it will not extract videos from streaming webpages or bypass subscriptions/DRM.
- Only download videos that the source explicitly allows you to download.
- Some streaming services only allow offline playback inside their own app.
